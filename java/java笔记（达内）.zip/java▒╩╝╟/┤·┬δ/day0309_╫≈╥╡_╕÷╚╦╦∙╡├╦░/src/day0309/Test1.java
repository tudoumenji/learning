package day0309;

import java.util.Scanner;

public class Test1 {
	public static void main(String[] args) {
		System.out.print("���ʣ�");
		double sal = new Scanner(System.in).nextDouble();
		double tax = f(sal);
		System.out.println(tax);
	}
	
	static double f(double sal) {
		//û�дﵽ������
		if(sal <= 3500) {
			return 0;
		}
		
		//�ٵ�3500
		sal -= 3500;
		
		//˰�ʺ�����۳�������
		double r = 0;
		int k = 0;
		
		//����sal�ķ�Χ����ȷ��r��k��ֵ
		if(sal<=1500) {
			r = 0.03;
			k = 0;
		} else if(sal<=4500) {
			r = 0.1;
			k = 105;
		} else if(sal<=9000) {
			r = 0.2;
			k = 555;
		} else if(sal<=35000) {
			r = 0.25;
			k = 1005;
		} else if(sal<=55000) {
			r = 0.3;
			k = 2755;
		} else if(sal<=80000) {
			r = 0.35;
			k = 5505;
		} else {
			r = 0.45;
			k = 13505;
		}
		
		return sal * r - k;
	}
	
}









