package day0101;

public class HelloWorld {
	public static void main(String[] args) {
	    System.out.println("Hello World!!!");
	    System.out.println("ʦ����ã�����");
	}
}
