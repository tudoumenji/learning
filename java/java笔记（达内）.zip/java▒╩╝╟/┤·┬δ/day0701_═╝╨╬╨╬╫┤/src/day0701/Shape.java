package day0701;

public abstract class Shape {
	public abstract void draw();
	
	public void clear() {
		System.out.println(
		 "\n\n\n\n\n\n\n\n\n\n\n\n�Ѳ���");  
	}
}
















