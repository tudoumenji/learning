package day0701;

public class Line extends Shape {
	@Override
	public void draw() {
		System.out.println("һ");
	}
	
	public void length() {
		System.out.println("һ�׶�...");
	}
}







