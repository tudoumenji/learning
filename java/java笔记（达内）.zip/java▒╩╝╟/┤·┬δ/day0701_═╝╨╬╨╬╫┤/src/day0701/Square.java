package day0701;

public class Square extends Shape {
	@Override
	public void draw() {
		System.out.println("��");
	}
}