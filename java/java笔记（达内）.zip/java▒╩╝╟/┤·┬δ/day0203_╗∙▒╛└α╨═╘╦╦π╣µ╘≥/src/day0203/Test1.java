package day0203;

public class Test1 {
	public static void main(String[] args) {
		System.out.println(3/2);
		System.out.println(3d/2);
		System.out.println("---------------");
		
		System.out.println('s' + 'b');
		System.out.println("---------------");
		
		System.out.println(Integer.MAX_VALUE+1);
		System.out.println(300000000*60*60*24*365);
		System.out.println(300000000L*60*60*24*365);
		System.out.println("---------------");
		
		System.out.println(2-1.9);
		System.out.println(2-1.8);
		System.out.println(2-1.7);
		System.out.println(2-1.6);
		System.out.println(2-1.5);
		System.out.println(4.35*100);
		System.out.println(4.36*100);
		System.out.println(4.37*100);
		System.out.println(4.38*100);
		System.out.println(4.39*100);
		System.out.println("---------------");
		
		System.out.println(3.14/0);
		System.out.println(Math.sqrt(-4));
	}
}






