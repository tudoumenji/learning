package day0601;

import java.util.Random;
import java.util.Scanner;

public class Test2 {
	public static void main(String[] args) {
		System.out.println("1.��");
		System.out.println("2.è");
		System.out.println("-------------");
		System.out.print("ѡ��");
		int c = new Scanner(System.in).nextInt();		
		System.out.print("������֣�");
		String n = new Scanner(System.in).nextLine();		

		Pet pet = null;
		
		if(c == 1) {
			pet = new Dog(n);
		} else {
			pet = new Cat(n);
		}
		
		play(pet);
	}

	private static void play(Pet pet) {
		while(true) {
			new Scanner(System.in).nextLine();
			int r = new Random().nextInt(3);
			switch(r) {
			case 0: pet.feed(); break;
			case 1: pet.play(); break;
			case 2: pet.punish(); break;
			}
		}
	}

	
}




