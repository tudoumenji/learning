package day1603;

public class C {
	public void c() {
		System.out.println("C.c()");
	}

}
