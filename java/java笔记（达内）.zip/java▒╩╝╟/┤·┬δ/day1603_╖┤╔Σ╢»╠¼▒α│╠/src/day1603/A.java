package day1603;

public class A {
	public void a() {
		System.out.println("A.a()");
	}
}
