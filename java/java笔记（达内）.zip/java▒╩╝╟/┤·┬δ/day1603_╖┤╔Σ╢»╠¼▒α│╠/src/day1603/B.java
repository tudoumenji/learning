package day1603;

public class B {
	public void b() {
		System.out.println("B.b()");
	}

}
