package day0201;

public class Test2 {
	public static void main(String[] args) {
		char c1 = 'a';
		char c2 = 97;
		char c3 = 'b';
		char c4 = 98;
		char c5 = '��';
		char c6 = 20013;
		char c7 = 20014;
		System.out.println(c1);
		System.out.println(c2);
		System.out.println(c3);
		System.out.println(c4);
		System.out.println(c5);
		System.out.println(c6);
		System.out.println(c7);
		
		
		char c8 = '\u0061';//97, a
		char c9 = '\u0062';//98, b
		char c10 = '\u4e2d';//20013, ��
		char c11 = '\u4e2e';//20014
		System.out.println(c8);
		System.out.println(c9);
		System.out.println(c10);
		System.out.println(c11);
		
		
	}
}




