package day0201;

public class Test1 {
	public static void main(String[] args) {
		//�ĸ����� abcd 
		//�ֱ𱣴�float��double��
		//��Сֵ�����ֵ
		float a = Float.MIN_VALUE;
		float b = Float.MAX_VALUE;
		double c = Double.MIN_VALUE;
		double d = Double.MAX_VALUE;
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		System.out.println(d);
	}
}
