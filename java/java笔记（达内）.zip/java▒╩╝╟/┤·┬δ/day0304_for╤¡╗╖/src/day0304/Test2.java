package day0304;

import java.util.Scanner;

public class Test2 {
	public static void main(String[] args) {
		System.out.println("\n\n-----------------");
		f1();
		System.out.println("\n\n-----------------");
		f2();
		System.out.println("\n\n-----------------");
		f3();
	}
	
	static void f3() {
		/*   i
		 *   1  *
		 *   2  **
		 *   3  ***
		 *   4  ****
		 *   n  *****
		 *      1234n j
		 */
		System.out.print("������");
		int n = new Scanner(System.in).nextInt();
		for(int i=1;i<=n;i++) {
			//��1��i���Ǻ�
			for(int j=1;j<=i;j++) {
				System.out.print("*");
			}
			System.out.println("*");
		}
	}
	
	static void f2() {
		/*
		 *   i
		 *   1 *****
		 *   2 *****
		 *   3 *****
		 *   4 *****
		 *   n *****
		 *     1234n j
		 */
		System.out.print("������");
		int n = new Scanner(System.in).nextInt();
		//iѭ������1��n��
		for(int i=1; i<=n; i++) {
			//jѭ������1��n���Ǻ�
			for(int j=1; j<=n; j++) {
				System.out.print("*");
			}
			//������
			System.out.println();
		}
	}

	static void f1() {
		for(int i=1; i<=3; i++) {
			for(char j='a'; j<='c'; j++) {
				System.out.println(i+", "+j);
			}
		}
	}
}





