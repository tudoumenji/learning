package day1304;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.Scanner;

public class Test1 {
	public static void main(String[] args) {
		System.out.println("ԭ�ļ���");
		String s1 = new Scanner(System.in).nextLine();
		File from = new File(s1);
		if(!from.isDirectory()) {
			System.out.println("�����ļ���");
			return;
		}
		
		
		System.out.println("Ŀ���ļ���");
		String s2 = new Scanner(System.in).nextLine();
		File to = new File(s2);
		if(to.isFile()) {
			System.out.println("�������ļ�");
			return;
		}
		
		try {
			copyDir(from,  to);
			System.out.println("���");
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("ʧ��");
		}
		
	}

	static void copyDir(File from, File to) throws Exception {
		if(! to.mkdirs()) {
			return;
		}
		
		File[] files = from.listFiles();
		if(files == null) {
			return;
		}
		
		for (File f : files) {
			if(f.isFile()) {
				copyFile(f, to);
			} else {
				copyDir(f, new File(to, f.getName()));
			}
		}
	}

	private static void copyFile(File from, File toDir) throws Exception {
		FileInputStream in = new FileInputStream(from);
		FileOutputStream out = new FileOutputStream(new File(toDir, from.getName()));
		
		byte[] buff = new byte[8192];
		int n;
		while((n = in.read(buff)) != -1) {
			out.write(buff, 0, n);
		}
		in.close();
		out.close();
	}
}









