package day0205;

public class Test1 {
	public static void main(String[] args) {
		System.out.println(1);
		f();
		System.out.println(2);
		f();
		System.out.println(3);
		f();
	}
	
	static void f() {
		System.out.println(4);
	}
	
}









