package day0804;

public interface Weapon {
	/* public abstract */
	void kill();
}
