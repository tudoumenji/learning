package day0906;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.Scanner;

public class Test1 {
	public static void main(String[] args) {
		System.out.println("�ַ�����");
		String s = new Scanner(System.in).nextLine();
		System.out.println("���ҵ��Ӵ���");
		String t = new Scanner(System.in).nextLine();
		
		LinkedList<Integer> a = find(s, t);
		System.out.println(a);
	}

	private static LinkedList<Integer> find(
			String s, String t) {
		/*
		 *       start
		 *         |
		 * s "abcabcabc"
		 * t "bc"
		 * 
		 * a [147       ]
		 *       i
		 * 
		 *   [0,1,2]
		 */
		LinkedList<Integer> list = new LinkedList<>();
		
		//��ѭ��������
		int start=0;
		while(true) {
			start = s.indexOf(t, start);
			if(start == -1) {
				break;
			}
			list.add(start);
			start++;
		}
		return list;
	}
}









