package day0604;

public class Employee extends Person {
	double salary;
	
}
