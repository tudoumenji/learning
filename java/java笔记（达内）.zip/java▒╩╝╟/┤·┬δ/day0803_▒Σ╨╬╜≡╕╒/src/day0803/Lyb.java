package day0803;

public class Lyb implements Weapon {
	public void kill() {
		System.out.println("ˣ��");
	}
	public String getName() {
		return "������";
	}
	public int getType() {
		return Weapon.TYPE_NUCLEAR;
	}
}
