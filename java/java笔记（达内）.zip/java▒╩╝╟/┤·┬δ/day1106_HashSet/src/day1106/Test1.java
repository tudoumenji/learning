package day1106;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class Test1 {
	public static void main(String[] args) {
		
		Set<Integer> set = new HashSet<>();
		set.add(888);
		set.add(222);
		set.add(666);
		set.add(777);
		set.add(111);
		set.add(999);
		set.add(777);
		set.add(777);
		System.out.println(set.size());
		System.out.println(set);
		System.out.println(set.remove(777));        
		System.out.println(set);
		//�������������Լ�д
		for(Iterator<Integer> it = set.iterator(); it.hasNext(); ) {
			Integer i = it.next();
			System.out.println(i);
		}
		
		Iterator<Integer> it = set.iterator();
		while(it.hasNext()) {
			Integer i = it.next();
			System.out.println(i);
		}
		
	}
}








