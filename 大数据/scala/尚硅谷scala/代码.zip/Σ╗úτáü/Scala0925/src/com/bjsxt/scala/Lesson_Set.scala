package com.bjsxt.scala

import scala.collection.immutable
import scala.collection.mutable
object Lesson_Set {
  def main(args: Array[String]): Unit = {
//    val set = mutable.Set[Int](1,2,3)
//    set.+=(100)
//    set.foreach(println)
//    val set1 = immutable.Set[String]("a","b")

//    val set = Set[Int](1,2,3,4)
//    val set1 = Set[Int](3,4,5,6)

//    val ints: Set[Int] = set.filter(elem => {
//      elem >= 2
//    })
//    ints.foreach(println)

//    val result = set &~ set1
//    result.foreach(println)

//    val result: Set[Int] = set1.diff(set)
//    result.foreach(println)

//    val result: Set[Int] = set.intersect(set1)
//    result.foreach(println)



//    for(elem<-set){
//      println(elem)
//    }
//    set.foreach(println)
  }
}
